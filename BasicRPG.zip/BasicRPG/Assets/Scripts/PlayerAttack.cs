using UnityEngine;

public class PlayerAttack : MonoBehaviour
{
    private int damage = 20;

    void Start()
    {

    }

    void Update()
    {

    }

    private void OnTriggerStay(Collider other)
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (other.gameObject.tag == "Enemy")
            {
                EnemyHealth enemyHealth = other.gameObject.GetComponent<EnemyHealth>();
                enemyHealth.Injure(damage);
            }
        }
    }
}
