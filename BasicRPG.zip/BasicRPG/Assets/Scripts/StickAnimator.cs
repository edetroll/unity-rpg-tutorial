using UnityEngine;

public class StickAnimator : MonoBehaviour
{
    Animator animator;

    void Start()
    {
        animator = GetComponent<Animator>();
    }

    void Update()
    {

        if (Input.GetKeyDown(KeyCode.Space))
        {
            //animator.Play("StickAnimation");
            animator.SetTrigger("TriggerHit");
        }
    }
}
