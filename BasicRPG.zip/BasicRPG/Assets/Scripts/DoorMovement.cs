using TMPro;
using UnityEngine;

public class DoorMovement : MonoBehaviour
{
    float minY = 1;
    float maxY = 10;
    public float speed = 10;
    int directionY = 0;
    public int minNrOfDiamondsToOpen = 3;

    public GameObject player;
    PlayerCollector playerCollector;

    public TextMeshProUGUI textGoToDoor;
    float elapsedTimeOfTextGoToDoor = 0;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        playerCollector = player.GetComponent<PlayerCollector>();
    }

    // Update is called once per frame
    void Update()
    {
        if (directionY == 1 && transform.position.y < maxY)
            transform.Translate(Vector3.up * speed * Time.deltaTime);
        else if (directionY == -1 && transform.position.y > minY)
            transform.Translate(Vector3.down * speed * Time.deltaTime);
        else directionY = 0;

        if (playerCollector.nrOfDiamondsCollected == minNrOfDiamondsToOpen)
        {
            textGoToDoor.gameObject.SetActive(true);
        }

        if (playerCollector.nrOfDiamondsCollected >= minNrOfDiamondsToOpen)
        {
            elapsedTimeOfTextGoToDoor += Time.deltaTime;
        }

        if (elapsedTimeOfTextGoToDoor >= 2)
        {
            textGoToDoor.gameObject.SetActive(false);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "Player")
        {
            if (playerCollector.nrOfDiamondsCollected >= minNrOfDiamondsToOpen)
                directionY = 1;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        directionY = -1;
    }
}
