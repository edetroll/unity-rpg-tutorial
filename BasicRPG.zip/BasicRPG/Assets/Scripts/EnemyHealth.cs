using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    int hp = 100;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Injure(int damage)
    {
        hp -= damage;

        if (hp <= 0)
            this.gameObject.SetActive(false);
    }
}
