using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float movementSpeed = 5;
    public float rotationSpeed = 100;

    void Start()
    {
        
    }

    void Update()
    {
        float verticalInput = Input.GetAxis("Vertical");
        float horizontalInput = Input.GetAxis("Horizontal");

        transform.Rotate(Vector3.up * rotationSpeed * horizontalInput * Time.deltaTime);
        transform.Translate(Vector3.forward * movementSpeed * verticalInput * Time.deltaTime);
    }
}
