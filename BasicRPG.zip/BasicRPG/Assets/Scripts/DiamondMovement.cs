using UnityEngine;

public class DiamondMovement : MonoBehaviour
{
    public float movementSpeed = 3;
    public float rotationSpeed = 150;
    public float minY = 1;
    public float maxY = 3;

    bool moveUp = true;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    float time = 0;
    // Update is called once per frame
    void Update()
    {
        transform.Rotate(Vector3.up * rotationSpeed * Time.deltaTime);

        if (moveUp && transform.position.y < maxY)
            transform.Translate(Vector3.up * movementSpeed * Time.deltaTime * (Mathf.Sin(time) + 1));
        else if (!moveUp && transform.position.y > minY)
            transform.Translate(Vector3.down * movementSpeed * Time.deltaTime * (Mathf.Sin(time) + 1));
        else
            moveUp = !moveUp;

        time += Time.deltaTime;
    }
}
