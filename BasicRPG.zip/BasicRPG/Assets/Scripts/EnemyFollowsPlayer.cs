using UnityEngine;

public class EnemyFollowsPlayer : MonoBehaviour
{
    GameObject player; // ide h�zod be az Inspectorban a j�t�kos objektumot
    public float speed = 2f; // milyen gyorsan k�zel�t
    public float rotationSpeed = 5f; // milyen gyorsan fordul fel�d

    void Start()
    {
        player = GameObject.Find("Player");       
    }

    void Update()
    {
        if (player == null) return;

        //1. Elfordul�s a c�l fel�
        Vector3 direction = player.transform.position - transform.position;
        Quaternion targetRotation = Quaternion.LookRotation(direction);
        transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, rotationSpeed * Time.deltaTime);

        // 2. K�zeled�s
        transform.position = Vector3.MoveTowards(transform.position, player.transform.position, speed * Time.deltaTime);
    }
}
