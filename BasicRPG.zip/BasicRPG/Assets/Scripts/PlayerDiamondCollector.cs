using TMPro;
using UnityEngine;

public class PlayerCollector : MonoBehaviour
{
    public int nrOfDiamondsCollected = 0;

    public TextMeshProUGUI textNrOfDiamondsCollected;

    private void OnTriggerEnter(Collider other)
    {
        //Debug.Log($"Player collided with {other.gameObject.name}");
        if (other.gameObject.tag == "Diamond")
        {
            nrOfDiamondsCollected++;
            textNrOfDiamondsCollected.text += "*";
            Destroy(other.gameObject);
        }
    }
}
